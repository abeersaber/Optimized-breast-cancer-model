close all
clear all
T=500;
N=20;%20
run=2;%20;%2
lb=0;%
ub=1;
threshold=2;

colorspec = {[1 0 0];[0 0 1];[0 0 0];[0 1 0];[0 1 1];[1 0 1];[.5 .5 0];[0 .4 .6]; [0.3 0.5 0.3]; [0.5 0.1 0.1]; ...
    [0.4 0.4 0.4]; [0.2 0.2 0.2];[.5 .4 .6]};
o=[1:20:T];
global A trn vald ;
fitfun=@jFitnessFunction; %fitness function 0.99Err+0.01*Selection Ratio
tlt='Exactly2';
Pc = 0.85;
Pm = 0.01;
Er = 0.05;
visualization = 0; % set to 0 if you do not want the convergence curve
Problem.obj =fitfun;
M = N; %  number of chromoHHOmes (cadinate HHOlutions)
Np          = 10;                    % Number of packs
Nc          = 3;
nn=1;
runs=2;%30;
nOnlooker=N;         % Number of Onlooker Bees
            % Acceleration Coefficient Upper Bound
            fn={'Zoo'};
    libb=['BDD/' cell2mat(fn) '.mat']
 Data1=load(libb);
Data1=Data1.A;
original_data=Data1(:,(1:end-1));
label=Data1(:,end);
clear Data1
feat=original_data;
dim = size(feat,2);
ff=size(feat,1);
%% results of Without FS 
 L=round(0.6*dim*N); % Abandonment Limit Parameter (Trial Limit)
d=1;
NG = dim;

for i=1:run
    ho = 0.2; 
% Hold-out method , 20% testing, 80% training 
HO = cvpartition(label,'HoldOut',ho);%,'Stratify',false
%% free memLshapecnEpSinry 
clear Result
clear RefereceResult
clear  c_matrix

clear sFeat_LshapecnEpSin;clear sFeat_Lshape;clear sFeat_GWO;clear sFeat_WOA;
clear sFeat_SCA;clear sFeat_GOA;clear sFeat_MFO;clear sFeat_AEO;clear sFeat_DMOA;
clear sFeat_mDMOA;
    display(['At run ', num2str(i)]);
     [sFeat_WOA,t_WOA(i),Nf_WOA(i),BestF_WOA(i),pos_WOA(i,:),CNVG_WOA(i,:)]=WOA(feat,label,HO,N,T,lb,ub, dim,fitfun);
    [sFeat_GWO,t_GWO(i),Nf_GWO(i),BestF_GWO(i),pos_GWO(i,:),CNVG_GWO(i,:)]=GWO(feat,label,HO,N,T,lb,ub, dim,fitfun);
    
    [acc_WOA(i),sensi_WOA(i),speci_WOA(i),prec_WOA(i)]=jKNN_all_performance(sFeat_WOA,label,HO);
    [acc_GWO(i),sensi_GWO(i),speci_GWO(i),prec_GWO(i)]=jKNN_all_performance(sFeat_GWO,label,HO);
    
end
% BestF_CrowSA=BestF_DMOA_new;
BestF_WOA_m=mean(BestF_WOA);
BestF_GWO_m=mean(BestF_GWO);

acc_WOA_m=mean(acc_WOA);
acc_GWO_m=mean(acc_GWO);

Nf_WOA_m=mean(Nf_WOA);
Nf_GWO_m=mean(Nf_GWO);

t_WOA_m=mean(t_WOA);
t_GWO_m=mean(t_GWO);

save(cell2mat(fn));
 x=[BestF_WOA_m;BestF_GWO_m;];
    algo=size(x,1);
     for k=1:size(x,1)
        [minm(k),index(k)]=min(x);
        x(index(k))=inf;
    end
    for k=1:size(x,1)
        [rank(k)]=find(index==k);
    end
clear Final_Results
     
       Final_Results(2,5)=[min(BestF_GWO)]
    Final_Results(3,5)=[max(BestF_GWO)]
    Final_Results(4,5)=[mean(BestF_GWO)]
    Final_Results(5,5)=[std(BestF_GWO)]
    %Final_Results(6,5)=[rank(8)]
       Final_Results(2,6)=[min(BestF_WOA)]
    Final_Results(3,6)=[max(BestF_WOA)]
    Final_Results(4,6)=[mean(BestF_WOA)]
    Final_Results(5,6)=[std(BestF_WOA)]
    %Final_Results(6,6)=[rank(7)]    
     
xlswrite('fitnessresults.xls',Final_Results,nn);
 x=[acc_WOA_m;acc_GWO_m;];

  for k=1:algo
            [maxmd(k),inSOxd(k)]=max(x);
            x(inSOxd(k))=-inf;
        end
        for k=1:algo
            [rank_acc(k)]=find(inSOxd==k);
        end
   Accuracy_Results(2,5)=[min(acc_GWO)]
    Accuracy_Results(3,5)=[max(acc_GWO)]
    Accuracy_Results(4,5)=[mean(acc_GWO)]
    Accuracy_Results(5,5)=[std(acc_GWO)]
    %Accuracy_Results(6,5)=[rank_acc(8)]
       Accuracy_Results(2,6)=[min(acc_WOA)]
    Accuracy_Results(3,6)=[max(acc_WOA)]
    Accuracy_Results(4,6)=[mean(acc_WOA)]
    Accuracy_Results(5,6)=[std(acc_WOA)]
    %Accuracy_Results(6,6)=[rank_acc(7)]    
    
    xlswrite('Acc.xls',Accuracy_Results,nn);
    
 x=[Nf_WOA_m; Nf_GWO_m;];    
algo=size(x,1);
     for k=1:size(x,1)
        [minm(k),index(k)]=min(x);
        x(index(k))=inf;
    end
    for k=1:size(x,1)
        [rank_NF(k)]=find(index==k);
    end
clear NoOfFeatures

    
    NoOfFeatures(2,5)=[min(Nf_GWO)]
    NoOfFeatures(3,5)=[max(Nf_GWO)]
    NoOfFeatures(4,5)=[mean(Nf_GWO)]
    NoOfFeatures(5,5)=[std(Nf_GWO)]
    %NoOfFeatures(6,5)=[rank_NF(8)]
       NoOfFeatures(2,6)=[min(Nf_WOA)]
    NoOfFeatures(3,6)=[max(Nf_WOA)]
    NoOfFeatures(4,6)=[mean(Nf_WOA)]
    NoOfFeatures(5,6)=[std(Nf_WOA)]
    %NoOfFeatures(6,6)=[rank_NF(7)]    
       
    xlswrite('NoOfFeatures.xls',NoOfFeatures,nn);

 x=[t_WOA_m;t_GWO_m;];    
    algo=size(x,1);
     for k=1:size(x,1)
        [minm(k),index(k)]=min(x);
        x(index(k))=inf;
    end
    for k=1:size(x,1)
        [rank_t(k)]=find(index==k);
    end
clear Ctime

       Ctime(2,5)=[min(t_GWO)]
    Ctime(3,5)=[max(t_GWO)]
    Ctime(4,5)=[mean(t_GWO)]
    Ctime(5,5)=[std(t_GWO)]
    %Ctime(6,5)=[rank_t(8)]
       Ctime(2,6)=[min(t_WOA)]
    Ctime(3,6)=[max(t_WOA)]
    Ctime(4,6)=[mean(t_WOA)]
    Ctime(5,6)=[std(t_WOA)]
    %Ctime(6,6)=[rank_t(7)]    
    
xlswrite('ct.xls',Ctime,nn);


 p(1) = ranksum(BestF_GWO,BestF_WOA);
    %p(2) = ranksum(BestF_mDMOA,BestF_WOA);
    
   
    xlswrite('wilxcon.xls',p,nn);

CNVG_GWO_m=mean(CNVG_GWO);
CNVG_WOA_m=mean(CNVG_WOA);

colorspec = {[1 0 0];[0 0 1];[0 0 0];[0 1 0];[0 1 1];[1 0 1];[.5 .5 0];[0 .4 .6]; [0.3 0.5 0.3]; [0.5 0.1 0.1]; ...
    [0.4 0.4 0.4]; [0.2 0.2 0.2];[.5 .4 .6]};
o=[1:20:T];

semilogy(CNVG_GWO_m,'Marker','diamond','MarkerIndices',o, 'Color', colorspec{6},'LineWidth',1)
hold on
semilogy(CNVG_WOA_m,'Marker','*', 'MarkerIndices',o,'Color', colorspec{3},'LineWidth',1)

grid on
title(tlt)
xlabel('Itration');
ylabel('Average Best So-far');
xlim([1 T]);
legend('GWO','WOA')
