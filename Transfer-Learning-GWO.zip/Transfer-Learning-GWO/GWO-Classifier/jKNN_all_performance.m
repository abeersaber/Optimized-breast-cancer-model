function [acc,sen,spec,prec] = jKNN_all_performance(sFeat,label,HO)
%---// Parameter setting for k-value of KNN //
k = 5; 

trainIdx = HO.training;        testIdx  = HO.test;
xtrain   = sFeat(trainIdx,:);  ytrain   = label(trainIdx);
xvalid   = sFeat(testIdx,:);   yvalid   = label(testIdx);

KNN  = fitcknn(xtrain,ytrain,'NumNeighbors',k);
pred = predict(KNN,xvalid);
%Acc  = jAccuracy(pred,yvalid); 
[c_matrix,Result,RefereceResult]= confusion.getMatrix(yvalid,pred,0);
% fprintf('\n Accuracy: %g %%',100 * Result.Accuracy);
acc=Result.Accuracy;
sen= Result.Sensitivity;
spec= Result.Specificity; 
prec= Result.Precision; 
end



