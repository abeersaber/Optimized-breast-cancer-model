for i=0:208
   
        img_name=num2str(i);
   
    im=imread(strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-BeforePreprcess\Data\Normal\',img_name,'.pgm'));
    [i,m]=gray2ind(im);
    im_rgb=ind2rgb(i,m);
    imwrite(im_rgb,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-BeforePreprcess\DATA-RGB\Normal\',img_name,'.png'));
end