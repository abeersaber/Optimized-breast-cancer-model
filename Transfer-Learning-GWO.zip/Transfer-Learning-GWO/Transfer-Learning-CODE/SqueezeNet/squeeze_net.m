imds = imageDatastore('F:\PHD\Transfer-Learning-using-Matlab-master\data2\AugmentedData', ...
    'IncludeSubfolders',true, ...
    'LabelSource','foldernames');
[imdsTrain,imdsValidation] = splitEachLabel(imds,0.8,'randomized');
net= squeezenet;
inputSize = net.Layers(1).InputSize
%analyzeNetwork(net)

net.Layers
layersTransfer = net.Layers(1:end-3);
%lgraph = removeLayers(lgraph, {'predictions','predictions_softmax','ClassificationLayer_predictions'});
numClasses = numel(categories(imdsTrain.Labels))
layers =[
    layersTransfer
    fullyConnectedLayer(numClasses,'WeightLearnRateFactor',20,'BiasLearnRateFactor',20)
    softmaxLayer
    classificationLayer];


pixelRange = [-30 30];
imageAugmenter = imageDataAugmenter( ...
    'RandXReflection',true, ...
    'RandXTranslation',pixelRange, ...
    'RandYTranslation',pixelRange);
augimdsTrain = augmentedImageDatastore(inputSize(1:2),imdsTrain, ...
    'DataAugmentation',imageAugmenter);
augimdsValidation = augmentedImageDatastore(inputSize(1:2),imdsValidation);
options = trainingOptions('sgdm', ...
    'MiniBatchSize',10, ...
  'LearnRateDropFactor',0.5, ... %0.2
    'InitialLearnRate',1e-4, ...    %1e-4
      'MaxEpochs',20, ...
    'ValidationData',augimdsValidation, ...
    'ValidationFrequency',3, ...
    'ValidationPatience',Inf, ...
    'Verbose',false ,...
    'Plots','training-progress');
net = trainNetwork(augimdsTrain,layers,options);
[YPred,scores] = classify(net,augimdsValidation);
cscores = scores;
accuracy = mean(YPred == imdsValidation.Labels)
idx = randperm(numel(imdsValidation.Files),4);
YValidation = imdsValidation.Labels;
plotconfusion(YValidation,YPred)
cgt=double(YValidation);
cg=double(YPred)
[tpr,fpr,thresholds] = roc(cgt',cg')
cscores = cscores';
[X1,Y1,T1,AUC1,OPTROCPT1,SUBY1,SUBYNAMES1] = perfcurve(cgt',cscores(1,:),1);
[X2,Y2,T2,AUC2,OPTROCPT2,SUBY2,SUBYNAMES2] = perfcurve(cgt',cscores(2,:),2);
[X3,Y3,T3,AUC3,OPTROCPT3,SUBY3,SUBYNAMES3] = perfcurve(cgt',cscores(3,:),3);
AUC=(AUC1+AUC2+AUC3)/3
figure, hold on , plot(X1,Y1),plot(X2,Y2),plot(X3,Y3)
figure,title('ROC for Classification CNN'),xlabel('False positive rate'),ylabel('True positive rate'), hold on , plot(X1,Y1),plot(X2,Y2),plot(X3,Y3)
%figure
