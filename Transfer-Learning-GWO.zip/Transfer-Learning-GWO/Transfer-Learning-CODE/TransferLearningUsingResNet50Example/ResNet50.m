%F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-BeforePreprcess\DATA-RGB
faccuracy=0;
imds = imageDatastore('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\RGBData_3', ...
    'IncludeSubfolders',true, ...
    'LabelSource','foldernames');
%[imdsTrain,imdsValidation] = splitEachLabel(imds,0.8,'randomized');
[imd1, imd2, imd3, imd4, imd5] = splitEachLabel(imds,0.1,0.1,0.1,0.1,'randomize');
partStores{1} = imd1.Files ;
partStores{2} = imd2.Files ;
partStores{3} = imd3.Files ;
partStores{4} = imd4.Files ;
partStores{5} = imd5.Files ;
k=5;
idx = crossvalind('Kfold', k, k);
for i = 1 :k
    
    test_idx = (idx == i);
    train_idx = ~test_idx;
    imdsValidation = imageDatastore(partStores{test_idx}, 'IncludeSubfolders', true,'FileExtensions','.png', 'LabelSource', 'foldernames');
      imdsTrain = imageDatastore(cat(1, partStores{train_idx}), 'IncludeSubfolders', true,'FileExtensions','.png', 'LabelSource', 'foldernames');
net = resnet50;
lgraph = layerGraph(net);
figure('Units','normalized','Position',[0.1 0.1 0.8 0.8]);
plot(lgraph)
net.Layers(1)
inputSize = net.Layers(1).InputSize;
net.Layers
lgraph = removeLayers(lgraph, {'fc1000','fc1000_softmax','ClassificationLayer_fc1000'});

numClasses = numel(categories(imdsTrain.Labels));
newLayers = [
    fullyConnectedLayer(numClasses,'Name','fc','WeightLearnRateFactor',10,'BiasLearnRateFactor',10)
    softmaxLayer('Name','softmax')
    classificationLayer('Name','classoutput')];
lgraph = addLayers(lgraph,newLayers);
lgraph = connectLayers(lgraph,'avg_pool','fc');

figure('Units','normalized','Position',[0.3 0.3 0.4 0.4]);
plot(lgraph)
ylim([0,10])
layers = lgraph.Layers;
connections = lgraph.Connections;

layers(1:110) = freezeWeights(layers(1:110));
lgraph = createLgraphUsingConnections(layers,connections);
pixelRange = [-30 30];
imageAugmenter = imageDataAugmenter( ...
    'RandXReflection',true, ...
    'RandXTranslation',pixelRange, ...
    'RandYTranslation',pixelRange);
augimdsTrain = augmentedImageDatastore(inputSize(1:2),imdsTrain, ...
    'DataAugmentation',imageAugmenter);
augimdsValidation = augmentedImageDatastore(inputSize(1:2),imdsValidation);
options = trainingOptions('sgdm', ...
    'MiniBatchSize',10, ...
  'LearnRateDropFactor',0.5, ... %0.2
    'InitialLearnRate',1e-4, ...    %1e-4
      'MaxEpochs',20, ...
    'ValidationData',augimdsValidation, ...
    'ValidationFrequency',3, ...
    'ValidationPatience',Inf, ...
    'Verbose',false ,...
    'Plots','training-progress');
net = trainNetwork(augimdsTrain,lgraph,options);
[YPred,scores] = classify(net,augimdsValidation);
cscores = scores;
accuracy = mean(YPred == imdsValidation.Labels)
faccuracy=accuracy+faccuracy;
%idx = randperm(numel(imdsValidation.Files),4);
YValidation = imdsValidation.Labels;
plotconfusion(YValidation,YPred)
cgt=double(YValidation);
cg=double(YPred)
[tpr,fpr,thresholds] = roc(cgt',cg')
cscores = cscores';
[X1,Y1,T1,AUC1,OPTROCPT1,SUBY1,SUBYNAMES1] = perfcurve(cgt',cscores(1,:),1);
[X2,Y2,T2,AUC2,OPTROCPT2,SUBY2,SUBYNAMES2] = perfcurve(cgt',cscores(2,:),2);
[X3,Y3,T3,AUC3,OPTROCPT3,SUBY3,SUBYNAMES3] = perfcurve(cgt',cscores(3,:),3);
AUC=(AUC1+AUC2+AUC3)/3
figure, hold on , plot(X1,Y1),plot(X2,Y2),plot(X3,Y3)
figure,title('ROC for Classification CNN'),xlabel('False positive rate'),ylabel('True positive rate'), hold on , plot(X1,Y1),plot(X2,Y2),plot(X3,Y3)

end
finalaccuracy=faccuracy/5;