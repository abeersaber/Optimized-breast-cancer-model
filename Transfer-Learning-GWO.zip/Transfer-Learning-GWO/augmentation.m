for i=0:60
   
        img_name=num2str(i);
   
   im=imread(strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\RGBData\Benign\',img_name,'.png'));
  
  x1=imrotate(im,0);
   
   imwrite(x1,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\Augmentation\Benign\',img_name,'A1.png'));
   f1 = flip(x1,2);
    imwrite(f1,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\Augmentation\Benign\',img_name,'A2.png'));
    x2=imrotate(im,90);
     imwrite(x2,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\Augmentation\Benign\',img_name,'A3.png'));
      f2 = flip(x2,2);
        imwrite(f2,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\Augmentation\Benign\',img_name,'A4.png'));
     x3=imrotate(im,180);
     imwrite(x3,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\Augmentation\Benign\',img_name,'A5.png'));
       f3 = flip(x3,2);
        imwrite(f3,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\Augmentation\Benign\',img_name,'A6.png'));
        x4=imrotate(im,270);
         imwrite(x4,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\Augmentation\Benign\',img_name,'A7.png'));
           f4 = flip(x4,2);
           imwrite(f4,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data-RS\Augmentation\Benign\',img_name,'A8.png'));
  %  x1=imrotate(im,0.5);
  
end