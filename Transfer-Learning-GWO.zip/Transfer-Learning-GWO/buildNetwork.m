imds = imageDatastore('C:\Users\yas\Desktop\Transfer-Learning-using-Matlab-master\buildNetwork\Data_RGB_AUG', ...
    'IncludeSubfolders',true, ...
    'LabelSource','foldernames');


labelCount = countEachLabel(imds)
img = readimage(imds,1);
size(img)

[imdsTrain,imdsValidation] = splitEachLabel(imds,0.8,'randomized');
layers = [
    imageInputLayer([224 224 3])
    % layer 1
    convolution2dLayer(3,32,'stride',2,'padding',1)
    batchNormalizationLayer
    reluLayer
    
    % layer 2
    convolution2dLayer(3,32,'stride',1,'padding',1)
    batchNormalizationLayer
    reluLayer
    
    % layer 3
    convolution2dLayer(1,64,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
    
    % layer 4
    convolution2dLayer(3,64,'stride',2,'padding',1)
    batchNormalizationLayer
    reluLayer
    
    % layer 5 
    convolution2dLayer(1,128,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
        
    % layer 6
    convolution2dLayer(3,128,'stride',1,'padding',1)
    batchNormalizationLayer
    reluLayer
   
    % layer 7
    convolution2dLayer(1,128,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
        
    % layer 8
    convolution2dLayer(3,128,'stride',2,'padding',1)
    batchNormalizationLayer
    reluLayer
  
    % layer 9
    convolution2dLayer(1,256,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
    
    % layer 10
    convolution2dLayer(3,256,'stride',1,'padding',1)
    batchNormalizationLayer
    reluLayer
    
    % layer 11
    convolution2dLayer(1,256,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
    
    % layer 12
    convolution2dLayer(3,256,'stride',2,'padding',1)
    batchNormalizationLayer
    reluLayer
    
    % layer 13
    convolution2dLayer(1,512,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
    
    % layer 14
    convolution2dLayer(3,512,'stride',1,'padding',1)
    batchNormalizationLayer
    reluLayer
    
    % layer -----
    convolution2dLayer(1,512,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
    
    % layer 23
    convolution2dLayer(3,512,'stride',2,'padding',1)
    batchNormalizationLayer
    reluLayer
    
    % layer 24
    convolution2dLayer(1,1024,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
    
    % layer 25
    convolution2dLayer(3,1024,'stride',1,'padding',1)
    batchNormalizationLayer
    reluLayer
    
    % layer 26
    convolution2dLayer(1,1024,'stride',1,'padding',0)
    batchNormalizationLayer
    reluLayer
    
     % layer 27
    averagePooling2dLayer(7,'Stride',1)
 
    % layer 28
    fullyConnectedLayer(3)
    % layer 29
    softmaxLayer
    classificationLayer];
options = trainingOptions('sgdm', ...
    'LearnRateDropFactor',0.5, ...
    'InitialLearnRate',0.002, ...
    'MaxEpochs',35, ...
    'Shuffle','every-epoch', ...
    'ValidationData',imdsValidation, ...
    'ValidationFrequency',30, ...
    'Verbose',false, ...
    'Plots','training-progress');
net = trainNetwork(imdsTrain,layers,options);
YPred = classify(net,imdsValidation);
YValidation = imdsValidation.Labels;

accuracy = sum(YPred == YValidation)/numel(YValidation)
plotconfusion(YValidation,YPred)