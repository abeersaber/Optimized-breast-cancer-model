
%for i=0:60
   
      %  img_name=num2str(i);
   
    %im=imread(strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data\PreprocessedData\Benign\',img_name,'.pgm'));


im=imread('F:\PHD\Transfer-Learning-using-Matlab-master\data2\PreprocessedData\Benign\51.pgm');


imbin=im2bw(im,0.6);

SE = strel('square',5);
imbin = imdilate(imbin,SE);
%figure; imshow(imbin); title('imbin');


%%

imbin = bwareaopen(imbin,5000);
%figure;imshow(imbin); title('Get rid of small areas in the mask');

im(~imbin)=0; 
%figure;
imshow(im); title('Get the nuclei chains without fragments');


%imwrite(im,strcat('F:\PHD\Transfer-Learning-using-Matlab-master\Final-Data\SegmentedData\Benign\',img_name,'.pgm'));
%end